const dummyData = [
  {
    key: 0,
    name: 'Dick Dale',
    age: 77
  },
  {
    key: 1,
    name: 'John Wick',
    age: 40
  },
  {
    key: 2,
    name: 'William Hester',
    age: 33
  }
]

export default dummyData
